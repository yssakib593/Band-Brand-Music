package com.bandbrandmusic.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
  private WebView web;
  private ValueCallback<Uri[]> uploadMessage;
  private final int FILE_CHOOSER_RESULT = 1;
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    web = new WebView(this);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(true);
    web.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
        if (uploadMessage != null) uploadMessage.onReceiveValue(null);
        uploadMessage = callback;
        Intent intent = params.createIntent();
        try { startActivityForResult(intent, FILE_CHOOSER_RESULT); }
        catch (Exception e) { uploadMessage = null; return false; }
        return true;
      }
    });
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode==FILE_CHOOSER_RESULT && uploadMessage!=null) {
      Uri[] results = (resultCode==RESULT_OK && data!=null && data.getData()!=null) ? new Uri[]{data.getData()} : null;
      uploadMessage.onReceiveValue(results); uploadMessage=null;
    }
  }
  @Override public void onBackPressed() {
    if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed();
  }
}