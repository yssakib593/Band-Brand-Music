# Band Brand Music

## Website
Open `website/index.html` in a modern browser. Add entries with a title, information and an optional image. Data is stored locally on the device/browser using IndexedDB. Use Export backup regularly; importing a backup restores entries.

## Android APK project
The `android` folder is an Android Studio project containing the same offline page inside a WebView.

To build the APK:
1. Install Android Studio on a computer and open the `android` folder.
2. Allow Gradle sync to finish (Android Gradle Plugin 8.7.3 and SDK 35 may be downloaded).
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio will show the generated APK location.

This package contains the Android project source, not a precompiled APK. An APK must be built with Android's build tools.
